function checkPoint3(){
//     alert4();
